library verilog;
use verilog.vl_types.all;
entity main_vlg_check_tst is
    port(
        DATA            : in     vl_logic_vector(11 downto 0);
        ERROR           : in     vl_logic;
        FIN             : in     vl_logic;
        PAUSA           : in     vl_logic;
        PRUEBA          : in     vl_logic_vector(11 downto 0);
        REGISTROa       : in     vl_logic_vector(11 downto 0);
        sampler_rx      : in     vl_logic
    );
end main_vlg_check_tst;
