-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "08/09/2025 15:40:57"

-- 
-- Device: Altera EP4CGX15BF14C6 Package FBGA169
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIV.CYCLONEIV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	main IS
    PORT (
	ERROR : OUT std_logic;
	CLOCK : IN std_logic;
	RECARGAR : IN std_logic;
	LOAD_F : IN std_logic;
	DATA : INOUT std_logic_vector(11 DOWNTO 0);
	LOAD_I : IN std_logic;
	START : IN std_logic;
	b2 : IN std_logic;
	b1 : IN std_logic;
	b0 : IN std_logic;
	\UP/DOWN\ : IN std_logic;
	CONTINUAR : IN std_logic
	);
END main;

-- Design Ports Information
-- ERROR	=>  Location: PIN_D10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[11]	=>  Location: PIN_K13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[10]	=>  Location: PIN_L13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[9]	=>  Location: PIN_F9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[8]	=>  Location: PIN_J13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[7]	=>  Location: PIN_L12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[6]	=>  Location: PIN_G10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[5]	=>  Location: PIN_G9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[4]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[3]	=>  Location: PIN_F10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[2]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[1]	=>  Location: PIN_E13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA[0]	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLOCK	=>  Location: PIN_J7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RECARGAR	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_I	=>  Location: PIN_K11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_F	=>  Location: PIN_K12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- START	=>  Location: PIN_D11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b2	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b1	=>  Location: PIN_E10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b0	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- UP/DOWN	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CONTINUAR	=>  Location: PIN_M13,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF main IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_ERROR : std_logic;
SIGNAL ww_CLOCK : std_logic;
SIGNAL ww_RECARGAR : std_logic;
SIGNAL ww_LOAD_F : std_logic;
SIGNAL ww_LOAD_I : std_logic;
SIGNAL ww_START : std_logic;
SIGNAL ww_b2 : std_logic;
SIGNAL ww_b1 : std_logic;
SIGNAL ww_b0 : std_logic;
SIGNAL \ww_UP/DOWN\ : std_logic;
SIGNAL ww_CONTINUAR : std_logic;
SIGNAL \CLOCK~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \DATA[11]~output_o\ : std_logic;
SIGNAL \DATA[10]~output_o\ : std_logic;
SIGNAL \DATA[9]~output_o\ : std_logic;
SIGNAL \DATA[8]~output_o\ : std_logic;
SIGNAL \DATA[7]~output_o\ : std_logic;
SIGNAL \DATA[6]~output_o\ : std_logic;
SIGNAL \DATA[5]~output_o\ : std_logic;
SIGNAL \DATA[4]~output_o\ : std_logic;
SIGNAL \DATA[3]~output_o\ : std_logic;
SIGNAL \DATA[2]~output_o\ : std_logic;
SIGNAL \DATA[1]~output_o\ : std_logic;
SIGNAL \DATA[0]~output_o\ : std_logic;
SIGNAL \ERROR~output_o\ : std_logic;
SIGNAL \CLOCK~input_o\ : std_logic;
SIGNAL \CLOCK~inputclkctrl_outclk\ : std_logic;
SIGNAL \DATA[11]~input_o\ : std_logic;
SIGNAL \RECARGAR~input_o\ : std_logic;
SIGNAL \LOAD_I~input_o\ : std_logic;
SIGNAL \inst7~combout\ : std_logic;
SIGNAL \inst|inst15~q\ : std_logic;
SIGNAL \DATA[6]~input_o\ : std_logic;
SIGNAL \DATA[7]~input_o\ : std_logic;
SIGNAL \DATA[8]~input_o\ : std_logic;
SIGNAL \DATA[5]~input_o\ : std_logic;
SIGNAL \DATA[1]~input_o\ : std_logic;
SIGNAL \UP/DOWN~input_o\ : std_logic;
SIGNAL \b1~input_o\ : std_logic;
SIGNAL \b0~input_o\ : std_logic;
SIGNAL \DATA[0]~input_o\ : std_logic;
SIGNAL \inst31|inst10|inst~combout\ : std_logic;
SIGNAL \inst31|inst11|inst3~0_combout\ : std_logic;
SIGNAL \b2~input_o\ : std_logic;
SIGNAL \DATA[2]~input_o\ : std_logic;
SIGNAL \inst31|inst12|inst3~0_combout\ : std_logic;
SIGNAL \DATA[4]~input_o\ : std_logic;
SIGNAL \DATA[3]~input_o\ : std_logic;
SIGNAL \inst31|inst16|inst2~combout\ : std_logic;
SIGNAL \inst31|inst19|inst2~combout\ : std_logic;
SIGNAL \DATA[10]~input_o\ : std_logic;
SIGNAL \DATA[9]~input_o\ : std_logic;
SIGNAL \inst31|inst22|inst4|3~combout\ : std_logic;
SIGNAL \inst31|inst19|inst4|3~combout\ : std_logic;
SIGNAL \inst31|inst21|inst4|3~combout\ : std_logic;
SIGNAL \LOAD_F~input_o\ : std_logic;
SIGNAL \inst8~combout\ : std_logic;
SIGNAL \inst2|inst14~q\ : std_logic;
SIGNAL \inst2|inst12~q\ : std_logic;
SIGNAL \inst30|inst12~2_combout\ : std_logic;
SIGNAL \inst2|inst13~q\ : std_logic;
SIGNAL \inst2|inst7~q\ : std_logic;
SIGNAL \inst30|inst12~5_combout\ : std_logic;
SIGNAL \inst30|inst12~6_combout\ : std_logic;
SIGNAL \inst2|inst15~q\ : std_logic;
SIGNAL \inst31|inst15|inst4|3~combout\ : std_logic;
SIGNAL \inst31|inst11|inst4|1~combout\ : std_logic;
SIGNAL \inst2|inst17~q\ : std_logic;
SIGNAL \inst2|inst8~q\ : std_logic;
SIGNAL \inst30|inst12~3_combout\ : std_logic;
SIGNAL \inst2|inst11~q\ : std_logic;
SIGNAL \inst30|inst7~combout\ : std_logic;
SIGNAL \inst30|inst12~4_combout\ : std_logic;
SIGNAL \inst2|inst16~q\ : std_logic;
SIGNAL \inst31|inst10|inst4|1~combout\ : std_logic;
SIGNAL \inst31|inst16|inst4|3~combout\ : std_logic;
SIGNAL \inst31|inst12|inst4|1~0_combout\ : std_logic;
SIGNAL \inst2|inst18~q\ : std_logic;
SIGNAL \inst2|inst9~q\ : std_logic;
SIGNAL \inst30|inst12~0_combout\ : std_logic;
SIGNAL \inst2|inst10~feeder_combout\ : std_logic;
SIGNAL \inst2|inst10~q\ : std_logic;
SIGNAL \inst30|inst6~combout\ : std_logic;
SIGNAL \inst30|inst12~1_combout\ : std_logic;
SIGNAL \inst30|inst12~combout\ : std_logic;
SIGNAL \inst30|inst14~q\ : std_logic;
SIGNAL \CONTINUAR~input_o\ : std_logic;
SIGNAL \START~input_o\ : std_logic;
SIGNAL \inst29|inst~0_combout\ : std_logic;
SIGNAL \inst29|inst1~combout\ : std_logic;
SIGNAL \inst29|inst2|inst20|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst24~0_combout\ : std_logic;
SIGNAL \inst27~combout\ : std_logic;
SIGNAL \inst1|inst15~q\ : std_logic;
SIGNAL \inst6~0_combout\ : std_logic;
SIGNAL \inst|inst14~q\ : std_logic;
SIGNAL \inst29|inst2|inst19|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst14~q\ : std_logic;
SIGNAL \inst|inst13~q\ : std_logic;
SIGNAL \inst29|inst2|inst18|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst13~q\ : std_logic;
SIGNAL \inst|inst12~q\ : std_logic;
SIGNAL \inst29|inst2|inst17|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst12~q\ : std_logic;
SIGNAL \inst31|inst18|inst4|3~combout\ : std_logic;
SIGNAL \inst|inst11~q\ : std_logic;
SIGNAL \inst29|inst2|inst16|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst11~q\ : std_logic;
SIGNAL \inst|inst10~q\ : std_logic;
SIGNAL \inst29|inst2|inst15|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst10~q\ : std_logic;
SIGNAL \inst|inst9~q\ : std_logic;
SIGNAL \inst29|inst2|inst14|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst9~q\ : std_logic;
SIGNAL \inst|inst8~q\ : std_logic;
SIGNAL \inst29|inst2|inst13|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst8~q\ : std_logic;
SIGNAL \inst|inst7~feeder_combout\ : std_logic;
SIGNAL \inst|inst7~q\ : std_logic;
SIGNAL \inst29|inst2|inst12|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst7~q\ : std_logic;
SIGNAL \inst|inst18~q\ : std_logic;
SIGNAL \inst29|inst2|inst11|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst18~q\ : std_logic;
SIGNAL \inst|inst17~q\ : std_logic;
SIGNAL \inst29|inst2|inst10|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst17~q\ : std_logic;
SIGNAL \inst|inst16~q\ : std_logic;
SIGNAL \inst29|inst2|inst|$00000|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \inst1|inst16~q\ : std_logic;
SIGNAL \inst9|inst127|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst127|inst3~1_combout\ : std_logic;
SIGNAL \inst9|inst127|inst3~2_combout\ : std_logic;
SIGNAL \inst9|inst127|inst3~3_combout\ : std_logic;
SIGNAL \inst9|inst128|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst129|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst130|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst131|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst132|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst133|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst134|inst3~0_combout\ : std_logic;
SIGNAL \inst9|inst134|ALT_INV_inst3~0_combout\ : std_logic;

BEGIN

ERROR <= ww_ERROR;
ww_CLOCK <= CLOCK;
ww_RECARGAR <= RECARGAR;
ww_LOAD_F <= LOAD_F;
ww_LOAD_I <= LOAD_I;
ww_START <= START;
ww_b2 <= b2;
ww_b1 <= b1;
ww_b0 <= b0;
\ww_UP/DOWN\ <= \UP/DOWN\;
ww_CONTINUAR <= CONTINUAR;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLOCK~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLOCK~input_o\);
\inst9|inst134|ALT_INV_inst3~0_combout\ <= NOT \inst9|inst134|inst3~0_combout\;

-- Location: IOOBUF_X33_Y15_N2
\DATA[11]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst15~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[11]~output_o\);

-- Location: IOOBUF_X33_Y12_N9
\DATA[10]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst14~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[10]~output_o\);

-- Location: IOOBUF_X33_Y25_N2
\DATA[9]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst13~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[9]~output_o\);

-- Location: IOOBUF_X33_Y15_N9
\DATA[8]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst12~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[8]~output_o\);

-- Location: IOOBUF_X33_Y12_N2
\DATA[7]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst11~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[7]~output_o\);

-- Location: IOOBUF_X33_Y22_N9
\DATA[6]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst10~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[6]~output_o\);

-- Location: IOOBUF_X33_Y22_N2
\DATA[5]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst9~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[5]~output_o\);

-- Location: IOOBUF_X33_Y14_N9
\DATA[4]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst8~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[4]~output_o\);

-- Location: IOOBUF_X33_Y24_N2
\DATA[3]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst7~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[3]~output_o\);

-- Location: IOOBUF_X33_Y24_N9
\DATA[2]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst18~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[2]~output_o\);

-- Location: IOOBUF_X33_Y25_N9
\DATA[1]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst17~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[1]~output_o\);

-- Location: IOOBUF_X33_Y14_N2
\DATA[0]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst16~q\,
	oe => \inst6~0_combout\,
	devoe => ww_devoe,
	o => \DATA[0]~output_o\);

-- Location: IOOBUF_X33_Y27_N9
\ERROR~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|inst134|ALT_INV_inst3~0_combout\,
	devoe => ww_devoe,
	o => \ERROR~output_o\);

-- Location: IOIBUF_X16_Y0_N15
\CLOCK~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK,
	o => \CLOCK~input_o\);

-- Location: CLKCTRL_G17
\CLOCK~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLOCK~inputclkctrl_outclk\);

-- Location: IOIBUF_X33_Y15_N1
\DATA[11]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(11),
	o => \DATA[11]~input_o\);

-- Location: IOIBUF_X33_Y28_N8
\RECARGAR~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RECARGAR,
	o => \RECARGAR~input_o\);

-- Location: IOIBUF_X33_Y11_N1
\LOAD_I~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_I,
	o => \LOAD_I~input_o\);

-- Location: LCCOMB_X32_Y19_N0
inst7 : cycloneiv_lcell_comb
-- Equation(s):
-- \inst7~combout\ = (\RECARGAR~input_o\ & \LOAD_I~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RECARGAR~input_o\,
	datac => \LOAD_I~input_o\,
	combout => \inst7~combout\);

-- Location: FF_X31_Y19_N17
\inst|inst15\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[11]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst15~q\);

-- Location: IOIBUF_X33_Y22_N8
\DATA[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(6),
	o => \DATA[6]~input_o\);

-- Location: IOIBUF_X33_Y12_N1
\DATA[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(7),
	o => \DATA[7]~input_o\);

-- Location: IOIBUF_X33_Y15_N8
\DATA[8]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(8),
	o => \DATA[8]~input_o\);

-- Location: IOIBUF_X33_Y22_N1
\DATA[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(5),
	o => \DATA[5]~input_o\);

-- Location: IOIBUF_X33_Y25_N8
\DATA[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(1),
	o => \DATA[1]~input_o\);

-- Location: IOIBUF_X29_Y31_N8
\UP/DOWN~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => \ww_UP/DOWN\,
	o => \UP/DOWN~input_o\);

-- Location: IOIBUF_X33_Y27_N1
\b1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b1,
	o => \b1~input_o\);

-- Location: IOIBUF_X31_Y31_N8
\b0~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b0,
	o => \b0~input_o\);

-- Location: IOIBUF_X33_Y14_N1
\DATA[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(0),
	o => \DATA[0]~input_o\);

-- Location: LCCOMB_X29_Y19_N6
\inst31|inst10|inst\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst10|inst~combout\ = (\DATA[0]~input_o\ & (\UP/DOWN~input_o\ $ (\b0~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \UP/DOWN~input_o\,
	datac => \b0~input_o\,
	datad => \DATA[0]~input_o\,
	combout => \inst31|inst10|inst~combout\);

-- Location: LCCOMB_X29_Y19_N12
\inst31|inst11|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst11|inst3~0_combout\ = (\DATA[1]~input_o\ & ((\inst31|inst10|inst~combout\) # (\UP/DOWN~input_o\ $ (\b1~input_o\)))) # (!\DATA[1]~input_o\ & (\inst31|inst10|inst~combout\ & (\UP/DOWN~input_o\ $ (\b1~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[1]~input_o\,
	datab => \UP/DOWN~input_o\,
	datac => \b1~input_o\,
	datad => \inst31|inst10|inst~combout\,
	combout => \inst31|inst11|inst3~0_combout\);

-- Location: IOIBUF_X29_Y31_N1
\b2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b2,
	o => \b2~input_o\);

-- Location: IOIBUF_X33_Y24_N8
\DATA[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(2),
	o => \DATA[2]~input_o\);

-- Location: LCCOMB_X29_Y19_N28
\inst31|inst12|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst12|inst3~0_combout\ = (\inst31|inst11|inst3~0_combout\ & ((\DATA[2]~input_o\) # (\UP/DOWN~input_o\ $ (\b2~input_o\)))) # (!\inst31|inst11|inst3~0_combout\ & (\DATA[2]~input_o\ & (\UP/DOWN~input_o\ $ (\b2~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst11|inst3~0_combout\,
	datab => \UP/DOWN~input_o\,
	datac => \b2~input_o\,
	datad => \DATA[2]~input_o\,
	combout => \inst31|inst12|inst3~0_combout\);

-- Location: IOIBUF_X33_Y14_N8
\DATA[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(4),
	o => \DATA[4]~input_o\);

-- Location: IOIBUF_X33_Y24_N1
\DATA[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(3),
	o => \DATA[3]~input_o\);

-- Location: LCCOMB_X29_Y19_N22
\inst31|inst16|inst2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst16|inst2~combout\ = (\DATA[5]~input_o\ & (\inst31|inst12|inst3~0_combout\ & (\DATA[4]~input_o\ & \DATA[3]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[5]~input_o\,
	datab => \inst31|inst12|inst3~0_combout\,
	datac => \DATA[4]~input_o\,
	datad => \DATA[3]~input_o\,
	combout => \inst31|inst16|inst2~combout\);

-- Location: LCCOMB_X31_Y19_N2
\inst31|inst19|inst2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst19|inst2~combout\ = (\DATA[6]~input_o\ & (\DATA[7]~input_o\ & (\DATA[8]~input_o\ & \inst31|inst16|inst2~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[6]~input_o\,
	datab => \DATA[7]~input_o\,
	datac => \DATA[8]~input_o\,
	datad => \inst31|inst16|inst2~combout\,
	combout => \inst31|inst19|inst2~combout\);

-- Location: IOIBUF_X33_Y12_N8
\DATA[10]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(10),
	o => \DATA[10]~input_o\);

-- Location: IOIBUF_X33_Y25_N1
\DATA[9]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => DATA(9),
	o => \DATA[9]~input_o\);

-- Location: LCCOMB_X31_Y19_N8
\inst31|inst22|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst22|inst4|3~combout\ = \DATA[11]~input_o\ $ (((\inst31|inst19|inst2~combout\ & (\DATA[10]~input_o\ & \DATA[9]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst19|inst2~combout\,
	datab => \DATA[10]~input_o\,
	datac => \DATA[11]~input_o\,
	datad => \DATA[9]~input_o\,
	combout => \inst31|inst22|inst4|3~combout\);

-- Location: LCCOMB_X31_Y19_N24
\inst31|inst19|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst19|inst4|3~combout\ = \DATA[8]~input_o\ $ (((\DATA[6]~input_o\ & (\DATA[7]~input_o\ & \inst31|inst16|inst2~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[6]~input_o\,
	datab => \DATA[8]~input_o\,
	datac => \DATA[7]~input_o\,
	datad => \inst31|inst16|inst2~combout\,
	combout => \inst31|inst19|inst4|3~combout\);

-- Location: LCCOMB_X31_Y19_N18
\inst31|inst21|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst21|inst4|3~combout\ = \DATA[10]~input_o\ $ (((\inst31|inst19|inst2~combout\ & \DATA[9]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst19|inst2~combout\,
	datab => \DATA[10]~input_o\,
	datad => \DATA[9]~input_o\,
	combout => \inst31|inst21|inst4|3~combout\);

-- Location: IOIBUF_X33_Y11_N8
\LOAD_F~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_F,
	o => \LOAD_F~input_o\);

-- Location: LCCOMB_X32_Y19_N30
inst8 : cycloneiv_lcell_comb
-- Equation(s):
-- \inst8~combout\ = (\LOAD_F~input_o\ & \RECARGAR~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LOAD_F~input_o\,
	datac => \RECARGAR~input_o\,
	combout => \inst8~combout\);

-- Location: FF_X31_Y19_N23
\inst2|inst14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[10]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst14~q\);

-- Location: FF_X31_Y19_N3
\inst2|inst12\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[8]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst12~q\);

-- Location: LCCOMB_X31_Y19_N22
\inst30|inst12~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~2_combout\ = (\inst31|inst19|inst4|3~combout\ & (\inst2|inst12~q\ & (\inst31|inst21|inst4|3~combout\ $ (!\inst2|inst14~q\)))) # (!\inst31|inst19|inst4|3~combout\ & (!\inst2|inst12~q\ & (\inst31|inst21|inst4|3~combout\ $ 
-- (!\inst2|inst14~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst19|inst4|3~combout\,
	datab => \inst31|inst21|inst4|3~combout\,
	datac => \inst2|inst14~q\,
	datad => \inst2|inst12~q\,
	combout => \inst30|inst12~2_combout\);

-- Location: FF_X31_Y19_N5
\inst2|inst13\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[9]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst13~q\);

-- Location: FF_X31_Y19_N11
\inst2|inst7\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[3]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst7~q\);

-- Location: LCCOMB_X31_Y19_N16
\inst30|inst12~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~5_combout\ = \DATA[3]~input_o\ $ (\inst31|inst12|inst3~0_combout\ $ (!\inst2|inst7~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[3]~input_o\,
	datab => \inst31|inst12|inst3~0_combout\,
	datad => \inst2|inst7~q\,
	combout => \inst30|inst12~5_combout\);

-- Location: LCCOMB_X31_Y19_N0
\inst30|inst12~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~6_combout\ = (\inst30|inst12~5_combout\ & (\inst31|inst19|inst2~combout\ $ (\inst2|inst13~q\ $ (!\DATA[9]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst19|inst2~combout\,
	datab => \inst2|inst13~q\,
	datac => \DATA[9]~input_o\,
	datad => \inst30|inst12~5_combout\,
	combout => \inst30|inst12~6_combout\);

-- Location: FF_X31_Y19_N9
\inst2|inst15\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[11]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst15~q\);

-- Location: LCCOMB_X29_Y19_N10
\inst31|inst15|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst15|inst4|3~combout\ = \DATA[4]~input_o\ $ (((\inst31|inst12|inst3~0_combout\ & \DATA[3]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst31|inst12|inst3~0_combout\,
	datac => \DATA[4]~input_o\,
	datad => \DATA[3]~input_o\,
	combout => \inst31|inst15|inst4|3~combout\);

-- Location: LCCOMB_X29_Y19_N20
\inst31|inst11|inst4|1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst11|inst4|1~combout\ = \DATA[1]~input_o\ $ (\UP/DOWN~input_o\ $ (\b1~input_o\ $ (\inst31|inst10|inst~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[1]~input_o\,
	datab => \UP/DOWN~input_o\,
	datac => \b1~input_o\,
	datad => \inst31|inst10|inst~combout\,
	combout => \inst31|inst11|inst4|1~combout\);

-- Location: FF_X31_Y19_N27
\inst2|inst17\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[1]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst17~q\);

-- Location: FF_X31_Y19_N29
\inst2|inst8\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[4]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst8~q\);

-- Location: LCCOMB_X31_Y19_N26
\inst30|inst12~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~3_combout\ = (\inst31|inst15|inst4|3~combout\ & (\inst2|inst8~q\ & (\inst31|inst11|inst4|1~combout\ $ (!\inst2|inst17~q\)))) # (!\inst31|inst15|inst4|3~combout\ & (!\inst2|inst8~q\ & (\inst31|inst11|inst4|1~combout\ $ (!\inst2|inst17~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst15|inst4|3~combout\,
	datab => \inst31|inst11|inst4|1~combout\,
	datac => \inst2|inst17~q\,
	datad => \inst2|inst8~q\,
	combout => \inst30|inst12~3_combout\);

-- Location: FF_X31_Y19_N25
\inst2|inst11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[7]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst11~q\);

-- Location: LCCOMB_X31_Y19_N12
\inst30|inst7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst7~combout\ = \DATA[7]~input_o\ $ (\inst2|inst11~q\ $ (((\DATA[6]~input_o\ & \inst31|inst16|inst2~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000011101111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[6]~input_o\,
	datab => \inst31|inst16|inst2~combout\,
	datac => \DATA[7]~input_o\,
	datad => \inst2|inst11~q\,
	combout => \inst30|inst7~combout\);

-- Location: LCCOMB_X31_Y19_N14
\inst30|inst12~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~4_combout\ = (\inst30|inst12~3_combout\ & (!\inst30|inst7~combout\ & (\inst31|inst22|inst4|3~combout\ $ (!\inst2|inst15~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst22|inst4|3~combout\,
	datab => \inst2|inst15~q\,
	datac => \inst30|inst12~3_combout\,
	datad => \inst30|inst7~combout\,
	combout => \inst30|inst12~4_combout\);

-- Location: FF_X32_Y19_N13
\inst2|inst16\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[0]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst16~q\);

-- Location: LCCOMB_X29_Y19_N24
\inst31|inst10|inst4|1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst10|inst4|1~combout\ = \UP/DOWN~input_o\ $ (\b0~input_o\ $ (\DATA[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \UP/DOWN~input_o\,
	datac => \b0~input_o\,
	datad => \DATA[0]~input_o\,
	combout => \inst31|inst10|inst4|1~combout\);

-- Location: LCCOMB_X29_Y19_N18
\inst31|inst16|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst16|inst4|3~combout\ = \DATA[5]~input_o\ $ (((\inst31|inst12|inst3~0_combout\ & (\DATA[4]~input_o\ & \DATA[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[5]~input_o\,
	datab => \inst31|inst12|inst3~0_combout\,
	datac => \DATA[4]~input_o\,
	datad => \DATA[3]~input_o\,
	combout => \inst31|inst16|inst4|3~combout\);

-- Location: LCCOMB_X29_Y19_N2
\inst31|inst12|inst4|1~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst12|inst4|1~0_combout\ = \inst31|inst11|inst3~0_combout\ $ (\UP/DOWN~input_o\ $ (\b2~input_o\ $ (\DATA[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst11|inst3~0_combout\,
	datab => \UP/DOWN~input_o\,
	datac => \b2~input_o\,
	datad => \DATA[2]~input_o\,
	combout => \inst31|inst12|inst4|1~0_combout\);

-- Location: FF_X32_Y19_N9
\inst2|inst18\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[2]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst18~q\);

-- Location: FF_X32_Y19_N29
\inst2|inst9\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[5]~input_o\,
	sload => VCC,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst9~q\);

-- Location: LCCOMB_X32_Y19_N4
\inst30|inst12~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~0_combout\ = (\inst31|inst16|inst4|3~combout\ & (\inst2|inst9~q\ & (\inst31|inst12|inst4|1~0_combout\ $ (!\inst2|inst18~q\)))) # (!\inst31|inst16|inst4|3~combout\ & (!\inst2|inst9~q\ & (\inst31|inst12|inst4|1~0_combout\ $ 
-- (!\inst2|inst18~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst16|inst4|3~combout\,
	datab => \inst31|inst12|inst4|1~0_combout\,
	datac => \inst2|inst18~q\,
	datad => \inst2|inst9~q\,
	combout => \inst30|inst12~0_combout\);

-- Location: LCCOMB_X32_Y19_N10
\inst2|inst10~feeder\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst2|inst10~feeder_combout\ = \DATA[6]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \DATA[6]~input_o\,
	combout => \inst2|inst10~feeder_combout\);

-- Location: FF_X32_Y19_N11
\inst2|inst10\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst2|inst10~feeder_combout\,
	ena => \inst8~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|inst10~q\);

-- Location: LCCOMB_X32_Y19_N24
\inst30|inst6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst6~combout\ = \inst31|inst16|inst2~combout\ $ (\DATA[6]~input_o\ $ (\inst2|inst10~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst31|inst16|inst2~combout\,
	datac => \DATA[6]~input_o\,
	datad => \inst2|inst10~q\,
	combout => \inst30|inst6~combout\);

-- Location: LCCOMB_X32_Y19_N6
\inst30|inst12~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~1_combout\ = (\inst30|inst12~0_combout\ & (!\inst30|inst6~combout\ & (\inst2|inst16~q\ $ (!\inst31|inst10|inst4|1~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|inst16~q\,
	datab => \inst31|inst10|inst4|1~combout\,
	datac => \inst30|inst12~0_combout\,
	datad => \inst30|inst6~combout\,
	combout => \inst30|inst12~1_combout\);

-- Location: LCCOMB_X30_Y19_N2
\inst30|inst12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst30|inst12~combout\ = (\inst30|inst12~2_combout\ & (\inst30|inst12~6_combout\ & (\inst30|inst12~4_combout\ & \inst30|inst12~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst30|inst12~2_combout\,
	datab => \inst30|inst12~6_combout\,
	datac => \inst30|inst12~4_combout\,
	datad => \inst30|inst12~1_combout\,
	combout => \inst30|inst12~combout\);

-- Location: FF_X30_Y19_N3
\inst30|inst14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst30|inst12~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst30|inst14~q\);

-- Location: IOIBUF_X33_Y10_N1
\CONTINUAR~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CONTINUAR,
	o => \CONTINUAR~input_o\);

-- Location: IOIBUF_X33_Y28_N1
\START~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_START,
	o => \START~input_o\);

-- Location: LCCOMB_X32_Y18_N0
\inst29|inst~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst~0_combout\ = (\CONTINUAR~input_o\ & \START~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \CONTINUAR~input_o\,
	datad => \START~input_o\,
	combout => \inst29|inst~0_combout\);

-- Location: LCCOMB_X30_Y19_N22
\inst29|inst1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst1~combout\ = (\RECARGAR~input_o\) # ((!\inst30|inst14~q\ & (\inst29|inst~0_combout\ & \inst30|inst12~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst30|inst14~q\,
	datab => \inst29|inst~0_combout\,
	datac => \RECARGAR~input_o\,
	datad => \inst30|inst12~combout\,
	combout => \inst29|inst1~combout\);

-- Location: LCCOMB_X30_Y19_N16
\inst29|inst2|inst20|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst20|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (\inst|inst15~q\)) # (!\inst29|inst1~combout\ & ((\inst31|inst22|inst4|3~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst15~q\,
	datab => \inst31|inst22|inst4|3~combout\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst20|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: LCCOMB_X29_Y19_N16
\inst24~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst24~0_combout\ = (\START~input_o\ & ((\b0~input_o\) # ((\b1~input_o\) # (\b2~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b0~input_o\,
	datab => \b1~input_o\,
	datac => \b2~input_o\,
	datad => \START~input_o\,
	combout => \inst24~0_combout\);

-- Location: LCCOMB_X30_Y19_N0
inst27 : cycloneiv_lcell_comb
-- Equation(s):
-- \inst27~combout\ = (\RECARGAR~input_o\) # (\inst24~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RECARGAR~input_o\,
	datac => \inst24~0_combout\,
	combout => \inst27~combout\);

-- Location: FF_X30_Y19_N17
\inst1|inst15\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst20|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst15~q\);

-- Location: LCCOMB_X30_Y19_N12
\inst6~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst6~0_combout\ = (\inst24~0_combout\ & ((\inst30|inst14~q\) # (!\inst30|inst12~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst30|inst14~q\,
	datac => \inst24~0_combout\,
	datad => \inst30|inst12~combout\,
	combout => \inst6~0_combout\);

-- Location: FF_X31_Y19_N31
\inst|inst14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[10]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst14~q\);

-- Location: LCCOMB_X30_Y19_N30
\inst29|inst2|inst19|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst19|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & ((\inst|inst14~q\))) # (!\inst29|inst1~combout\ & (\inst31|inst21|inst4|3~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst21|inst4|3~combout\,
	datab => \inst|inst14~q\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst19|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N31
\inst1|inst14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst19|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst14~q\);

-- Location: FF_X31_Y19_N1
\inst|inst13\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[9]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst13~q\);

-- Location: LCCOMB_X30_Y19_N24
\inst29|inst2|inst18|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst18|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (((\inst|inst13~q\)))) # (!\inst29|inst1~combout\ & (\DATA[9]~input_o\ $ ((\inst31|inst19|inst2~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[9]~input_o\,
	datab => \inst31|inst19|inst2~combout\,
	datac => \inst29|inst1~combout\,
	datad => \inst|inst13~q\,
	combout => \inst29|inst2|inst18|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N25
\inst1|inst13\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst18|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst13~q\);

-- Location: FF_X31_Y19_N7
\inst|inst12\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[8]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst12~q\);

-- Location: LCCOMB_X30_Y19_N26
\inst29|inst2|inst17|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst17|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (\inst|inst12~q\)) # (!\inst29|inst1~combout\ & ((\inst31|inst19|inst4|3~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst12~q\,
	datab => \inst31|inst19|inst4|3~combout\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst17|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N27
\inst1|inst12\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst17|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst12~q\);

-- Location: LCCOMB_X31_Y19_N6
\inst31|inst18|inst4|3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst31|inst18|inst4|3~combout\ = \DATA[7]~input_o\ $ (((\DATA[6]~input_o\ & \inst31|inst16|inst2~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[6]~input_o\,
	datab => \DATA[7]~input_o\,
	datad => \inst31|inst16|inst2~combout\,
	combout => \inst31|inst18|inst4|3~combout\);

-- Location: FF_X31_Y19_N13
\inst|inst11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[7]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst11~q\);

-- Location: LCCOMB_X30_Y19_N8
\inst29|inst2|inst16|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst16|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & ((\inst|inst11~q\))) # (!\inst29|inst1~combout\ & (\inst31|inst18|inst4|3~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst18|inst4|3~combout\,
	datab => \inst|inst11~q\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst16|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N9
\inst1|inst11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst16|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst11~q\);

-- Location: FF_X32_Y19_N25
\inst|inst10\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[6]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst10~q\);

-- Location: LCCOMB_X30_Y19_N6
\inst29|inst2|inst15|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst15|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (\inst|inst10~q\)) # (!\inst29|inst1~combout\ & ((\inst31|inst16|inst2~combout\ $ (\DATA[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001110101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst10~q\,
	datab => \inst31|inst16|inst2~combout\,
	datac => \inst29|inst1~combout\,
	datad => \DATA[6]~input_o\,
	combout => \inst29|inst2|inst15|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N7
\inst1|inst10\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst15|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst10~q\);

-- Location: FF_X32_Y19_N23
\inst|inst9\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[5]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst9~q\);

-- Location: LCCOMB_X30_Y19_N28
\inst29|inst2|inst14|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst14|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (\inst|inst9~q\)) # (!\inst29|inst1~combout\ & ((\inst31|inst16|inst4|3~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst9~q\,
	datab => \inst31|inst16|inst4|3~combout\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst14|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N29
\inst1|inst9\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst14|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst9~q\);

-- Location: FF_X31_Y19_N19
\inst|inst8\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[4]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst8~q\);

-- Location: LCCOMB_X30_Y19_N18
\inst29|inst2|inst13|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst13|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & ((\inst|inst8~q\))) # (!\inst29|inst1~combout\ & (\inst31|inst15|inst4|3~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst15|inst4|3~combout\,
	datab => \inst|inst8~q\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst13|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N19
\inst1|inst8\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst13|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst8~q\);

-- Location: LCCOMB_X32_Y19_N16
\inst|inst7~feeder\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst7~feeder_combout\ = \DATA[3]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \DATA[3]~input_o\,
	combout => \inst|inst7~feeder_combout\);

-- Location: FF_X32_Y19_N17
\inst|inst7\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst|inst7~feeder_combout\,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst7~q\);

-- Location: LCCOMB_X29_Y19_N0
\inst29|inst2|inst12|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst12|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (((\inst|inst7~q\)))) # (!\inst29|inst1~combout\ & (\DATA[3]~input_o\ $ ((\inst31|inst12|inst3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \DATA[3]~input_o\,
	datab => \inst31|inst12|inst3~0_combout\,
	datac => \inst|inst7~q\,
	datad => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst12|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X29_Y19_N1
\inst1|inst7\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst12|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst7~q\);

-- Location: FF_X32_Y19_N27
\inst|inst18\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[2]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst18~q\);

-- Location: LCCOMB_X30_Y19_N20
\inst29|inst2|inst11|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst11|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & ((\inst|inst18~q\))) # (!\inst29|inst1~combout\ & (\inst31|inst12|inst4|1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst12|inst4|1~0_combout\,
	datac => \inst29|inst1~combout\,
	datad => \inst|inst18~q\,
	combout => \inst29|inst2|inst11|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N21
\inst1|inst18\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst11|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst18~q\);

-- Location: FF_X31_Y19_N21
\inst|inst17\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[1]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst17~q\);

-- Location: LCCOMB_X30_Y19_N10
\inst29|inst2|inst10|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst10|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & (\inst|inst17~q\)) # (!\inst29|inst1~combout\ & ((\inst31|inst11|inst4|1~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst17~q\,
	datab => \inst31|inst11|inst4|1~combout\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst10|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N11
\inst1|inst17\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst10|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst17~q\);

-- Location: FF_X32_Y19_N19
\inst|inst16\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	asdata => \DATA[0]~input_o\,
	sload => VCC,
	ena => \inst7~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst16~q\);

-- Location: LCCOMB_X30_Y19_N4
\inst29|inst2|inst|$00000|auto_generated|result_node[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst29|inst2|inst|$00000|auto_generated|result_node[0]~0_combout\ = (\inst29|inst1~combout\ & ((\inst|inst16~q\))) # (!\inst29|inst1~combout\ & (\inst31|inst10|inst4|1~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst31|inst10|inst4|1~combout\,
	datab => \inst|inst16~q\,
	datac => \inst29|inst1~combout\,
	combout => \inst29|inst2|inst|$00000|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X30_Y19_N5
\inst1|inst16\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputclkctrl_outclk\,
	d => \inst29|inst2|inst|$00000|auto_generated|result_node[0]~0_combout\,
	ena => \inst27~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|inst16~q\);

-- Location: LCCOMB_X32_Y19_N14
\inst9|inst127|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst127|inst3~0_combout\ = (\inst|inst17~q\ & (((!\inst2|inst16~q\ & \inst|inst16~q\)) # (!\inst2|inst17~q\))) # (!\inst|inst17~q\ & (!\inst2|inst16~q\ & (!\inst2|inst17~q\ & \inst|inst16~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100110100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|inst16~q\,
	datab => \inst|inst17~q\,
	datac => \inst2|inst17~q\,
	datad => \inst|inst16~q\,
	combout => \inst9|inst127|inst3~0_combout\);

-- Location: LCCOMB_X32_Y19_N28
\inst9|inst127|inst3~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst127|inst3~1_combout\ = (\inst|inst18~q\ & ((\inst9|inst127|inst3~0_combout\) # (!\inst2|inst18~q\))) # (!\inst|inst18~q\ & (\inst9|inst127|inst3~0_combout\ & !\inst2|inst18~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst18~q\,
	datab => \inst9|inst127|inst3~0_combout\,
	datad => \inst2|inst18~q\,
	combout => \inst9|inst127|inst3~1_combout\);

-- Location: LCCOMB_X32_Y19_N12
\inst9|inst127|inst3~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst127|inst3~2_combout\ = (\inst|inst7~q\ & ((\inst9|inst127|inst3~1_combout\) # (!\inst2|inst7~q\))) # (!\inst|inst7~q\ & (\inst9|inst127|inst3~1_combout\ & !\inst2|inst7~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst7~q\,
	datab => \inst9|inst127|inst3~1_combout\,
	datad => \inst2|inst7~q\,
	combout => \inst9|inst127|inst3~2_combout\);

-- Location: LCCOMB_X31_Y19_N28
\inst9|inst127|inst3~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst127|inst3~3_combout\ = (\inst|inst8~q\ & ((\inst9|inst127|inst3~2_combout\) # (!\inst2|inst8~q\))) # (!\inst|inst8~q\ & (!\inst2|inst8~q\ & \inst9|inst127|inst3~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst|inst8~q\,
	datac => \inst2|inst8~q\,
	datad => \inst9|inst127|inst3~2_combout\,
	combout => \inst9|inst127|inst3~3_combout\);

-- Location: LCCOMB_X32_Y19_N8
\inst9|inst128|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst128|inst3~0_combout\ = (\inst|inst9~q\ & ((\inst9|inst127|inst3~3_combout\) # (!\inst2|inst9~q\))) # (!\inst|inst9~q\ & (!\inst2|inst9~q\ & \inst9|inst127|inst3~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst9~q\,
	datab => \inst2|inst9~q\,
	datad => \inst9|inst127|inst3~3_combout\,
	combout => \inst9|inst128|inst3~0_combout\);

-- Location: LCCOMB_X32_Y19_N20
\inst9|inst129|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst129|inst3~0_combout\ = (\inst|inst10~q\ & ((\inst9|inst128|inst3~0_combout\) # (!\inst2|inst10~q\))) # (!\inst|inst10~q\ & (!\inst2|inst10~q\ & \inst9|inst128|inst3~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001010110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst10~q\,
	datab => \inst2|inst10~q\,
	datac => \inst9|inst128|inst3~0_combout\,
	combout => \inst9|inst129|inst3~0_combout\);

-- Location: LCCOMB_X31_Y19_N20
\inst9|inst130|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst130|inst3~0_combout\ = (\inst|inst11~q\ & ((\inst9|inst129|inst3~0_combout\) # (!\inst2|inst11~q\))) # (!\inst|inst11~q\ & (!\inst2|inst11~q\ & \inst9|inst129|inst3~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst11~q\,
	datab => \inst2|inst11~q\,
	datad => \inst9|inst129|inst3~0_combout\,
	combout => \inst9|inst130|inst3~0_combout\);

-- Location: LCCOMB_X31_Y19_N10
\inst9|inst131|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst131|inst3~0_combout\ = (\inst|inst12~q\ & ((\inst9|inst130|inst3~0_combout\) # (!\inst2|inst12~q\))) # (!\inst|inst12~q\ & (\inst9|inst130|inst3~0_combout\ & !\inst2|inst12~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst12~q\,
	datab => \inst9|inst130|inst3~0_combout\,
	datad => \inst2|inst12~q\,
	combout => \inst9|inst131|inst3~0_combout\);

-- Location: LCCOMB_X31_Y19_N4
\inst9|inst132|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst132|inst3~0_combout\ = (\inst9|inst131|inst3~0_combout\ & ((\inst|inst13~q\) # (!\inst2|inst13~q\))) # (!\inst9|inst131|inst3~0_combout\ & (!\inst2|inst13~q\ & \inst|inst13~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|inst131|inst3~0_combout\,
	datac => \inst2|inst13~q\,
	datad => \inst|inst13~q\,
	combout => \inst9|inst132|inst3~0_combout\);

-- Location: LCCOMB_X31_Y19_N30
\inst9|inst133|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst133|inst3~0_combout\ = (\inst2|inst14~q\ & (\inst9|inst132|inst3~0_combout\ & \inst|inst14~q\)) # (!\inst2|inst14~q\ & ((\inst9|inst132|inst3~0_combout\) # (\inst|inst14~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|inst14~q\,
	datab => \inst9|inst132|inst3~0_combout\,
	datac => \inst|inst14~q\,
	combout => \inst9|inst133|inst3~0_combout\);

-- Location: LCCOMB_X32_Y19_N2
\inst9|inst134|inst3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst9|inst134|inst3~0_combout\ = (\inst|inst15~q\ & ((\inst9|inst133|inst3~0_combout\) # (!\inst2|inst15~q\))) # (!\inst|inst15~q\ & (\inst9|inst133|inst3~0_combout\ & !\inst2|inst15~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst15~q\,
	datac => \inst9|inst133|inst3~0_combout\,
	datad => \inst2|inst15~q\,
	combout => \inst9|inst134|inst3~0_combout\);

ww_ERROR <= \ERROR~output_o\;

DATA(11) <= \DATA[11]~output_o\;

DATA(10) <= \DATA[10]~output_o\;

DATA(9) <= \DATA[9]~output_o\;

DATA(8) <= \DATA[8]~output_o\;

DATA(7) <= \DATA[7]~output_o\;

DATA(6) <= \DATA[6]~output_o\;

DATA(5) <= \DATA[5]~output_o\;

DATA(4) <= \DATA[4]~output_o\;

DATA(3) <= \DATA[3]~output_o\;

DATA(2) <= \DATA[2]~output_o\;

DATA(1) <= \DATA[1]~output_o\;

DATA(0) <= \DATA[0]~output_o\;
END structure;


